libraries used in the project:
1. copy (import copy)
2. numpy (import numpy as np)

Instructions to run the code:
- As soon the code is run, the input for initial node position will be taken from user.
- For that, enter the numbers for initial node position row wise, one by one.
- Press enter after entering each number.
- Use 0 for the posotion of blank tile
- Enter numbers from 0 to 9 only.
- Make sure that no number is repeated.



- If the puzzle is solvable, the code will display that puzzle is solvable and it is finding the solution. It will generated the expected notepad files in required format.
- Code from plot.py file provided is used to print the steps of solution.
- If the puzzle is not solavble, the code will declare it as insolvable and it will not try to find the solution.