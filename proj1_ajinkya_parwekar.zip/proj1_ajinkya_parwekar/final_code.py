import copy

#initial_node_position = [[7, 5, 4], [0, 3, 2], [8, 1, 6]]
print("Enter the initial node position in numbers, row wise, one by one: (use 0 for blank tile, enter numbers between 0 to 8 only, no number should be repeated): ")
#taking input from user for initial node position
initial_node_position = []
for i in range(3):
   a =[]
   for j in range(3):
        a.append(int(input()))
   initial_node_position.append(a)

Matrix_8puzzle_Nodes = []    #matrix containing all explored nodes
Matrix_8puzzle_Nodes.append(initial_node_position)
new_list = []
index_list = []     #matrix containing index of all nodes as well as their parent nodes


def blank_tile_position(list):       #added function to find the position of blank tile for any given initial node state
    for i in range(0, 3):
        for j in range(0, 3):
            if list[i][j] == 0:
                return [i, j]


def action_move_left(list):         #added function to move the blank tile in left direction by 1 unit, if possible
    [x, y] = blank_tile_position(list)
    new_list = copy.deepcopy(list)
    if y != 0:
        temp = new_list[x][y]
        new_list[x][y] = new_list[x][y - 1]
        new_list[x][y - 1] = temp

    return new_list


def action_move_right(list):        #added function to move the blank tile in right direction by 1 unit, if possible
    [x, y] = blank_tile_position(list)
    new_list = copy.deepcopy(list)
    if y != 2:
        temp = new_list[x][y]
        new_list[x][y] = new_list[x][y + 1]
        new_list[x][y + 1] = temp

    return new_list


def action_move_up(list):        #added function to move the blank tile in upward direction by 1 unit, if possible
    [x, y] = blank_tile_position(list)
    new_list = copy.deepcopy(list)
    if x != 0:
        temp = new_list[x][y]
        new_list[x][y] = new_list[x - 1][y]
        new_list[x - 1][y] = temp

    return new_list


def action_move_down(list):        #added function to move the blank tile in downward direction by 1 unit, if possible
    [x, y] = blank_tile_position(list)
    new_list = copy.deepcopy(list)
    if x != 2:
        temp = new_list[x][y]
        new_list[x][y] = new_list[x + 1][y]
        new_list[x + 1][y] = temp

    return new_list

list_1d = []  # for breaking list of list into list
for sublist in initial_node_position:
    for item in sublist:
        list_1d.append(item)
inverse_count = 0        #initialising inversion counter
for i in range(9):       #for checking if puzzle is solvable or not
    if list_1d[i] == 0:
        pass
    else:
        sit = list_1d[i]
        for o in range(i+1, 9):
            if sit < list_1d[o] or list_1d[o] == 0:
                continue
            else:
                inverse_count += 1             #finding total number of inversions

if inverse_count % 2 == 0:      #if so, the puzzle is solvable
    print("The puzzle is solvable, finding solution...")
    # main code
    for z in Matrix_8puzzle_Nodes:
        l = action_move_left(z)
        if l in Matrix_8puzzle_Nodes:   #checking if new node is in data structure or not
            pass
        else:
            Matrix_8puzzle_Nodes.append(l)      #appending the Matrix_8puzzle_Nodes list with newly created node
            index_list.append([Matrix_8puzzle_Nodes.index(l), Matrix_8puzzle_Nodes.index(z)])        #adding index of new node as well as its parent node to the list
        if l == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Solution Found! and notepad file created")
            break

        r = action_move_right(z)
        if r in Matrix_8puzzle_Nodes:   #checking if new node is in data structure or not
            pass
        else:
            Matrix_8puzzle_Nodes.append(r)      #appending the Matrix_8puzzle_Nodes list with newly created node
            index_list.append([Matrix_8puzzle_Nodes.index(r), Matrix_8puzzle_Nodes.index(z)])        #adding index of new node as well as its parent node to the list
        if r == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Solution Found! and notepad file created")
            break

        u = action_move_up(z)
        if u in Matrix_8puzzle_Nodes:   #checking if new node is in data structure or not
            pass
        else:
            Matrix_8puzzle_Nodes.append(u)      #appending the Matrix_8puzzle_Nodes list with newly created node
            index_list.append([Matrix_8puzzle_Nodes.index(u), Matrix_8puzzle_Nodes.index(z)])        #adding index of new node as well as its parent node to the list
        if u == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Solution Found! and notepad file created")
            break

        d = action_move_down(z)
        if d in Matrix_8puzzle_Nodes:   #checking if new node is in data structure or not
            pass
        else:
            Matrix_8puzzle_Nodes.append(d)      #appending the Matrix_8puzzle_Nodes list with newly created node
            index_list.append([Matrix_8puzzle_Nodes.index(d), Matrix_8puzzle_Nodes.index(z)])        #adding index of new node as well as its parent node to the list
        if d == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Solution Found! and notepad file created")
            break


    # code for backtracking
    def back_tracking(index_list):
        list_for_t = []  # for breaking list of list into list
        for sublist in index_list:
            for item in sublist:
                list_for_t.append(item)

        list_into_dict = {list_for_t[i]: list_for_t[i + 1] for i in range(0, len(list_for_t), 2)}     #converting list into dictionary
        last_ele = index_list[-1][0]     #node state of solution
        y = last_ele
        back_track = []
        solution_nodes = []  # matrix containing nodes of final solution
        while y != 0:
            back_track.append([y, list_into_dict[y]])      #appending list of indexes nodes and corresponding parent nodes into list
            solution_nodes.append(Matrix_8puzzle_Nodes[y])   #appending corresponding node states into solution nodes list
            y = list_into_dict[y]

        solution_nodes.append(initial_node_position)
        return list(reversed(back_track)), list(reversed(solution_nodes))      #returning list of solution from start position to end position


    p, q = back_tracking(index_list)

    # for generating output text files
    MyFile1 = open('nodePath.txt', 'w')
    for element in q:
        for i in range(0, 3):
            for j in range(0, 3):
                MyFile1.write(str(element[j][i]) + " ")
        MyFile1.write('\n')                              #for creating nodePath.txt file

    MyFile1.close()

    MyFile2 = open('NodesInfo.txt', 'w')
    for element in p:
        for i in range(0, 2):
            MyFile2.write(str(element[i]) + " ")
        MyFile2.write('\n')                              #for creating NodesInfo.txt file

    MyFile2.close()

    MyFile3 = open('Nodes.txt', 'w')
    for element in Matrix_8puzzle_Nodes:
        for i in range(0, 3):
            for j in range(0, 3):
                MyFile3.write(str(element[j][i]) + " ")
        MyFile3.write('\n')                              #for creating Nodes.txt file

    MyFile3.close()

    import numpy as np

    #code from plot.py file for printing steps of the solution
    def print_matrix(state):
        counter = 0
        for row in range(0, len(state), 3):
            if counter == 0:
                print("-------------")
            for element in range(counter, len(state), 3):
                if element <= counter:
                    print("|", end=" ")
                print(int(state[element]), "|", end=" ")
            counter = counter + 1
            print("\n-------------")


    f_name = 'nodePath.txt'
    data = np.loadtxt(f_name)
    if len(data[1]) != 9:
        print("Format of the text file is incorrect, retry ")
    else:
        for i in range(0, len(data)):
            if i == 0:
                print("Start Node")
            elif i == len(data) - 1:
                print("Achieved Goal Node")
            else:
                print("Step ", i)
            print_matrix(data[i])
            print()
            print()

else:       #if the inversion count is odd, declare the puzzle as insolvable
    print("The puzzle is insolvable")